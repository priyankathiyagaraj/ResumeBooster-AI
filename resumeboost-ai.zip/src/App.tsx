/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorker from 'pdfjs-dist/build/pdf.worker.mjs?url';
import { 
  Upload, 
  FileText, 
  Briefcase, 
  CheckCircle2, 
  AlertCircle, 
  Zap, 
  Target, 
  ListChecks, 
  RefreshCw,
  Search,
  ChevronRight,
  Star
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Utility for Tailwind class merging
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// PDF.js worker setup
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

// --- Types ---
interface AnalysisResult {
  resume_score: number;
  skills: string[];
  projects: string[];
  keywords: string[];
  missing_skills: string[];
  summary: string;
  suggestions: {
    summary: string[];
    projects: string[];
    skills: string[];
    experience: string[];
  };
  improvement_tasks: string[];
  alignment_feedback: string;
}

// --- Gemini Configuration ---
const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    resume_score: { type: Type.NUMBER, description: "Score out of 10" },
    skills: { type: Type.ARRAY, items: { type: Type.STRING } },
    projects: { type: Type.ARRAY, items: { type: Type.STRING } },
    keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
    missing_skills: { type: Type.ARRAY, items: { type: Type.STRING } },
    summary: { type: Type.STRING, description: "Exactly 2 lines professional summary" },
    suggestions: {
      type: Type.OBJECT,
      properties: {
        summary: { type: Type.ARRAY, items: { type: Type.STRING } },
        projects: { type: Type.ARRAY, items: { type: Type.STRING } },
        skills: { type: Type.ARRAY, items: { type: Type.STRING } },
        experience: { type: Type.ARRAY, items: { type: Type.STRING } },
      },
      required: ["summary", "projects", "skills", "experience"]
    },
    improvement_tasks: { type: Type.ARRAY, items: { type: Type.STRING }, description: "3 actionable tasks to reach 8/10" },
    alignment_feedback: { type: Type.STRING }
  },
  required: ["resume_score", "skills", "projects", "keywords", "missing_skills", "summary", "suggestions", "improvement_tasks", "alignment_feedback"]
};

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [jobTitle, setJobTitle] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [improvedText, setImprovedText] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Functions ---

  const extractTextFromPDF = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = "";
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item: any) => item.str).join(" ");
      fullText += pageText + "\n";
    }
    return fullText;
  };

  const analyzeResume = async (resumeText: string) => {
    if (!jobTitle || !jobDescription) {
      setError("Please provide both job title and description.");
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      const model = "gemini-3-flash-preview";
      const prompt = `
        Analyze the following resume against the target job title and description.
        
        Target Job Title: ${jobTitle}
        Job Description: ${jobDescription}
        
        Resume Text:
        ${resumeText}
        
        Return the analysis in the specified JSON format. 
        Ensure the summary is exactly 2 lines. 
        Suggestions should be practical and short.
        Improvement tasks should be actionable.
      `;

      const response = await genAI.models.generateContent({
        model,
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: ANALYSIS_SCHEMA,
        },
      });

      const parsedResult = JSON.parse(response.text || "{}");
      setResult(parsedResult);
    } catch (err) {
      console.error(err);
      setError("Failed to analyze resume. Please check your API key or try again later.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setError(null);
    } else {
      setError("Please upload a valid PDF file.");
    }
  };

  const onAnalyzeClick = async () => {
    if (!file) {
      setError("Please upload a resume first.");
      return;
    }
    const text = await extractTextFromPDF(file);
    await analyzeResume(text);
  };

  const onReEvaluateClick = async () => {
    if (!improvedText) {
      setError("Please paste the improved resume text.");
      return;
    }
    await analyzeResume(improvedText);
  };

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-emerald-500";
    if (score >= 5) return "text-amber-500";
    return "text-rose-500";
  };

  return (
    <div className="min-h-screen font-sans selection:bg-[#141414] selection:text-[#E4E3E0]">
      {/* Header */}
      <header className="border-b border-[#141414] bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <motion.div 
              whileHover={{ rotate: 180 }}
              className="w-10 h-10 bg-[#141414] text-[#E4E3E0] flex items-center justify-center rounded-lg shadow-lg"
            >
              <Zap size={24} />
            </motion.div>
            <h1 className="text-xl font-bold tracking-tighter uppercase italic font-serif">AI Resume Analyzer</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden md:block text-[10px] uppercase tracking-widest opacity-50 font-mono">
              Hackathon Edition v1.0
            </div>
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
        
        {/* Left Column: Inputs */}
        <div className="lg:col-span-4 space-y-8 lg:sticky lg:top-24 lg:h-fit">
          <motion.section 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass-card p-6 rounded-2xl"
          >
            <div className="flex items-center gap-2 mb-4">
              <Upload size={18} />
              <h2 className="text-xs uppercase tracking-widest font-bold font-mono">1. Upload Resume</h2>
            </div>
            
            <div 
              onClick={() => fileInputRef.current?.click()}
              className={cn(
                "relative overflow-hidden border-2 border-dashed border-[#141414]/20 rounded-xl p-8 text-center cursor-pointer transition-all hover:bg-[#141414]/5",
                file && "border-emerald-500/50 bg-emerald-50/50"
              )}
            >
              {isAnalyzing && (
                <div className="absolute inset-0 pointer-events-none">
                  <div className="w-full h-1 bg-emerald-500/30 animate-scan absolute top-0" />
                </div>
              )}
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileUpload} 
                accept=".pdf" 
                className="hidden" 
              />
              {file ? (
                <div className="flex flex-col items-center gap-2">
                  <CheckCircle2 className="text-emerald-500" size={32} />
                  <span className="text-sm font-medium truncate max-w-full">{file.name}</span>
                  <span className="text-[10px] uppercase opacity-50">Click to change</span>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2">
                  <FileText className="opacity-20" size={32} />
                  <span className="text-sm">Drop PDF here or click to browse</span>
                  <span className="text-[10px] uppercase opacity-50">PDF only, max 5MB</span>
                </div>
              )}
            </div>
          </motion.section>

          <motion.section 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="glass-card p-6 rounded-2xl space-y-4"
          >
            <div className="flex items-center gap-2 mb-2">
              <Target size={18} />
              <h2 className="text-xs uppercase tracking-widest font-bold font-mono">2. Target Role</h2>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="text-[10px] uppercase tracking-wider opacity-50 mb-1 block">Job Title</label>
                <input 
                  type="text" 
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  placeholder="e.g. Senior Frontend Engineer"
                  className="w-full bg-white/50 border border-[#141414]/10 p-3 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#141414]/20 transition-all"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-wider opacity-50 mb-1 block">Job Description</label>
                <textarea 
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  placeholder="Paste the job description here..."
                  rows={6}
                  className="w-full bg-white/50 border border-[#141414]/10 p-3 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#141414]/20 transition-all resize-none"
                />
              </div>
            </div>

            <motion.button 
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onAnalyzeClick}
              disabled={isAnalyzing || !file}
              className={cn(
                "w-full py-4 rounded-xl font-bold uppercase tracking-widest text-sm transition-all flex items-center justify-center gap-2 neo-shadow",
                isAnalyzing || !file 
                  ? "bg-[#141414]/10 text-[#141414]/30 cursor-not-allowed shadow-none" 
                  : "bg-[#141414] text-[#E4E3E0] hover:bg-[#2a2a2a]"
              )}
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="animate-spin" size={18} />
                  Analyzing...
                </>
              ) : (
                <>
                  <Search size={18} />
                  Analyze Resume
                </>
              )}
            </motion.button>
          </motion.section>

          {error && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-rose-50 border border-rose-200 p-4 rounded-xl flex items-start gap-3 text-rose-600"
            >
              <AlertCircle size={18} className="shrink-0 mt-0.5" />
              <p className="text-xs font-medium">{error}</p>
            </motion.div>
          )}
        </div>

        {/* Right Column: Results */}
        <div className="lg:col-span-8">
          <AnimatePresence mode="wait">
            {!result && !isAnalyzing ? (
              <motion.div 
                key="empty"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="h-full min-h-[500px] border-2 border-dashed border-[#141414]/5 rounded-[2.5rem] flex flex-col items-center justify-center text-center p-12 bg-white/20"
              >
                <div className="relative mb-8">
                  <div className="w-24 h-24 bg-white border border-[#141414]/10 rounded-3xl flex items-center justify-center shadow-2xl rotate-3">
                    <FileText size={40} className="opacity-10" />
                  </div>
                  <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-[#141414] text-white rounded-xl flex items-center justify-center shadow-lg -rotate-12">
                    <Zap size={20} />
                  </div>
                </div>
                <h3 className="text-2xl font-serif italic mb-3">Awaiting Data Input</h3>
                <p className="text-sm opacity-40 max-w-xs leading-relaxed">
                  Upload your professional credentials and target role to initiate the semantic alignment analysis.
                </p>
                <div className="mt-8 flex gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#141414]/10" />
                  <div className="w-1.5 h-1.5 rounded-full bg-[#141414]/10" />
                  <div className="w-1.5 h-1.5 rounded-full bg-[#141414]/10" />
                </div>
              </motion.div>
            ) : isAnalyzing ? (
              <motion.div 
                key="loading"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className="h-full min-h-[500px] glass-card rounded-3xl p-12 flex flex-col items-center justify-center text-center neo-shadow-lg"
              >
                <div className="relative mb-12">
                  <div className="w-32 h-32 border-4 border-[#141414]/5 rounded-full"></div>
                  <div className="w-32 h-32 border-4 border-t-[#141414] rounded-full absolute top-0 animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Zap className="animate-pulse text-[#141414]" size={40} />
                  </div>
                  {/* Scanning line animation */}
                  <motion.div 
                    animate={{ top: ["0%", "100%", "0%"] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                    className="absolute left-0 right-0 h-0.5 bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)] z-10"
                  />
                </div>
                <h3 className="text-2xl font-serif italic mb-3">Gemini is Deciphering...</h3>
                <p className="text-sm opacity-50 max-w-sm leading-relaxed">
                  Extracting semantic skills, mapping project impact, and calculating ATS compatibility benchmarks.
                </p>
                
                <div className="mt-12 w-full max-w-sm bg-[#141414]/5 h-1.5 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: "100%" }}
                    transition={{ duration: 15, ease: "linear" }}
                    className="h-full bg-[#141414]"
                  />
                </div>
                <div className="mt-4 font-mono text-[10px] uppercase tracking-widest opacity-30 animate-pulse">
                  Processing Neural Context...
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="result"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
              >
                {/* Score & Summary */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
                  <motion.div 
                    whileHover={{ y: -5 }}
                    className="md:col-span-4 glass-card p-8 rounded-3xl flex flex-col items-center justify-center text-center neo-shadow-lg"
                  >
                    <span className="text-[10px] uppercase tracking-widest font-bold font-mono mb-4 opacity-50">ATS Match Score</span>
                    <div className={cn("text-8xl font-serif italic font-black mb-4 tracking-tighter", getScoreColor(result!.resume_score))}>
                      {result!.resume_score}<span className="text-2xl opacity-20 ml-1">/10</span>
                    </div>
                    <div className="flex gap-1.5">
                      {[...Array(10)].map((_, i) => (
                        <motion.div 
                          key={i} 
                          initial={{ height: 0 }}
                          animate={{ height: 24 }}
                          transition={{ delay: i * 0.05 }}
                          className={cn(
                            "w-2 rounded-full",
                            i < result!.resume_score ? "bg-[#141414]" : "bg-[#141414]/10"
                          )}
                        />
                      ))}
                    </div>
                  </motion.div>
                  
                  <motion.div 
                    whileHover={{ y: -5 }}
                    className="md:col-span-8 glass-card p-8 rounded-3xl neo-shadow-lg"
                  >
                    <div className="flex items-center gap-2 mb-6">
                      <Star size={18} className="text-amber-500 fill-amber-500" />
                      <h2 className="text-xs uppercase tracking-widest font-bold font-mono">Professional Summary</h2>
                    </div>
                    <p className="text-2xl font-serif italic leading-snug text-[#141414]/90">
                      "{result!.summary}"
                    </p>
                    <div className="mt-8 pt-8 border-t border-[#141414]/10">
                      <div className="flex items-center gap-2 mb-3">
                        <Target size={14} className="opacity-50" />
                        <span className="text-[10px] uppercase font-bold font-mono opacity-50">Role Alignment Analysis</span>
                      </div>
                      <p className="text-sm opacity-60 leading-relaxed font-medium">{result!.alignment_feedback}</p>
                    </div>
                  </motion.div>
                </div>

                {/* Skills & Keywords */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <motion.div 
                    whileHover={{ scale: 1.01 }}
                    className="glass-card p-6 rounded-3xl"
                  >
                    <div className="flex items-center gap-2 mb-6">
                      <div className="w-6 h-6 rounded-full bg-emerald-500/10 flex items-center justify-center">
                        <CheckCircle2 size={14} className="text-emerald-600" />
                      </div>
                      <h2 className="text-xs uppercase tracking-widest font-bold font-mono">Extracted Skills</h2>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {result!.skills.map((skill, i) => (
                        <motion.span 
                          key={i} 
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: i * 0.03 }}
                          className="px-3 py-1.5 bg-white border border-[#141414]/10 rounded-lg text-[11px] font-bold tracking-tight shadow-sm hover:border-[#141414] transition-colors cursor-default"
                        >
                          {skill}
                        </motion.span>
                      ))}
                    </div>
                  </motion.div>

                  <motion.div 
                    whileHover={{ scale: 1.01 }}
                    className="glass-card p-6 rounded-3xl"
                  >
                    <div className="flex items-center gap-2 mb-6">
                      <div className="w-6 h-6 rounded-full bg-rose-500/10 flex items-center justify-center">
                        <AlertCircle size={14} className="text-rose-600" />
                      </div>
                      <h2 className="text-xs uppercase tracking-widest font-bold font-mono">Missing Skills</h2>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {result!.missing_skills.length > 0 ? result!.missing_skills.map((skill, i) => (
                        <motion.span 
                          key={i} 
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: i * 0.03 }}
                          className="px-3 py-1.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-[11px] font-bold tracking-tight shadow-sm"
                        >
                          {skill}
                        </motion.span>
                      )) : (
                        <div className="w-full py-4 text-center border border-dashed border-emerald-500/20 rounded-xl bg-emerald-50/30">
                          <span className="text-xs text-emerald-600 font-bold uppercase tracking-widest">Perfect Skill Match</span>
                        </div>
                      )}
                    </div>
                  </motion.div>
                </div>

                {/* Improvement Tasks */}
                <motion.div 
                  whileHover={{ y: -5 }}
                  className="bg-[#141414] text-[#E4E3E0] p-10 rounded-[2.5rem] shadow-[12px_12px_0px_0px_rgba(20,20,20,0.1)] relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
                  <div className="flex items-center gap-3 mb-8 relative z-10">
                    <ListChecks size={24} className="text-emerald-400" />
                    <h2 className="text-sm uppercase tracking-[0.2em] font-bold font-mono">Optimization Roadmap</h2>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
                    {result!.improvement_tasks.map((task, i) => (
                      <motion.div 
                        key={i} 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="space-y-4 p-6 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
                      >
                        <div className="text-4xl font-serif italic opacity-20">0{i + 1}</div>
                        <p className="text-sm leading-relaxed font-medium">{task}</p>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>

                {/* Detailed Suggestions */}
                <div className="glass-card p-10 rounded-[2.5rem] neo-shadow-lg">
                  <div className="flex items-center gap-3 mb-10">
                    <Briefcase size={20} className="opacity-50" />
                    <h2 className="text-xs uppercase tracking-widest font-bold font-mono">Section-wise Optimization</h2>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                    {(Object.entries(result!.suggestions) as [string, string[]][]).map(([section, items], idx) => (
                      <motion.div 
                        key={section} 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: idx * 0.1 }}
                        className="space-y-5"
                      >
                        <h3 className="text-[11px] uppercase font-black tracking-[0.2em] text-[#141414]/40 flex items-center gap-3">
                          <div className="w-8 h-[1px] bg-[#141414]/20" />
                          {section}
                        </h3>
                        <ul className="space-y-4">
                          {items.map((item, i) => (
                            <li key={i} className="text-sm flex gap-4 items-start group">
                              <div className="w-1.5 h-1.5 rounded-full bg-[#141414]/20 mt-2 shrink-0 group-hover:bg-[#141414] transition-colors" />
                              <span className="leading-relaxed opacity-80 group-hover:opacity-100 transition-opacity">{item}</span>
                            </li>
                          ))}
                        </ul>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Re-evaluation Section */}
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="glass-card p-10 rounded-[2.5rem] neo-shadow-lg bg-emerald-50/30"
                >
                  <div className="flex items-center gap-3 mb-6">
                    <RefreshCw size={20} className="text-emerald-600" />
                    <h2 className="text-xs uppercase tracking-widest font-bold font-mono">Iterative Improvement</h2>
                  </div>
                  <p className="text-sm opacity-60 mb-6 max-w-2xl leading-relaxed">
                    Apply the suggestions above to your resume text and paste it here. Our AI will re-calculate your score to track your progress.
                  </p>
                  <div className="relative">
                    <textarea 
                      value={improvedText}
                      onChange={(e) => setImprovedText(e.target.value)}
                      placeholder="Paste your optimized resume content here..."
                      rows={6}
                      className="w-full bg-white/80 border border-[#141414]/10 p-6 rounded-2xl text-sm mb-6 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 transition-all resize-none shadow-inner"
                    />
                    <div className="absolute bottom-10 right-6 text-[10px] font-mono opacity-20 uppercase tracking-widest">
                      {improvedText.length} characters
                    </div>
                  </div>
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={onReEvaluateClick}
                    disabled={isAnalyzing || !improvedText}
                    className="flex items-center gap-3 px-8 py-4 bg-[#141414] text-[#E4E3E0] rounded-2xl text-xs uppercase font-bold tracking-[0.2em] neo-shadow hover:bg-[#2a2a2a] transition-all disabled:opacity-20 disabled:shadow-none"
                  >
                    <RefreshCw size={16} className={isAnalyzing ? "animate-spin" : ""} />
                    Sync & Re-analyze
                  </motion.button>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#141414]/10 mt-12 bg-white/30 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 py-12 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2 opacity-30">
            <Zap size={14} />
            <span className="text-[10px] uppercase font-bold tracking-widest">Built for Hackathons</span>
          </div>
          <div className="flex gap-8">
            <a href="#" className="text-[10px] uppercase font-bold tracking-widest opacity-30 hover:opacity-100 transition-opacity">Documentation</a>
            <a href="#" className="text-[10px] uppercase font-bold tracking-widest opacity-30 hover:opacity-100 transition-opacity">GitHub</a>
            <a href="#" className="text-[10px] uppercase font-bold tracking-widest opacity-30 hover:opacity-100 transition-opacity">Privacy</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
